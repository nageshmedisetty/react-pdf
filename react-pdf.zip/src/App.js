import React from 'react'
import PDFDocument from './PDFDocument'

const App = () => {
  return (
    <PDFDocument />
  )
}

export default App