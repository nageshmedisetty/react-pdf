import React from 'react'
import { PDFViewer, Font, Page, Document, StyleSheet } from '@react-pdf/renderer';
import { Header, MoverSection, Divider, CustomerSection, ServiceDates, DigitalSignatureSection, ValuationDeclaration, WeightCharges } from './components'
import TermsPage from './components/TermsPage'
import TermsPageTwo from './components/TermsPageTwo'
import TermsPageThree from './components/TermsPageThree';

const PDFDocument = () => {
    return (
        <PDFViewer style={styles.viewer}>
            <Document>
                
                <Page style={styles.body}>
                    <MoverSection />
                    <Divider />
                    <CustomerSection />
                    <Divider />
                    <ServiceDates />
                    <Divider />
                    <DigitalSignatureSection />
                    <ValuationDeclaration />
                    <WeightCharges />
                    <TermsPage />
                    <TermsPageTwo />
                    <TermsPageThree />
                </Page>
            </Document>
        </PDFViewer >
    )
}

export default PDFDocument

Font.register({
    family: 'Oswald',
    src: 'https://fonts.gstatic.com/s/oswald/v13/Y_TKV6o8WovbUd3m_X9aAA.ttf'
});

const styles = StyleSheet.create({
    viewer: {
        width: "100vw", //the pdf viewer will take up all of the width and height
        height: "100vh",
    },
    body: {
        fontSize: 12,
    },
    title: {
        fontSize: 24,
        textAlign: 'center',
        fontFamily: 'Oswald'
    },
    author: {
        fontSize: 12,
        textAlign: 'center',
        marginBottom: 40,
    },
    subtitle: {
        fontSize: 18,
        margin: 12,
        fontFamily: 'Oswald'
    },
    text: {
        margin: 12,
        fontSize: 14,
        textAlign: 'justify',
        fontFamily: 'Times-Roman'
    },
    image: {
        marginVertical: 15,
        marginHorizontal: 100,
    },
    header: {
        fontSize: 12,
        marginBottom: 20,
        textAlign: 'center',
        color: 'grey',
    },
    pageNumber: {
        position: 'absolute',
        fontSize: 12,
        bottom: 30,
        left: 0,
        right: 0,
        textAlign: 'center',
        color: 'grey',
    },
});