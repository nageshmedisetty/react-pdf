import React from 'react'
import { Text, View, Link } from '@react-pdf/renderer';
const CustomerSection = () => {
    return (
        <View style={{
            display: 'flex', flexDirection: 'row', color: '#000',
            justifyContent: 'space-between', paddingBottom: 12, paddingTop: 12
        }}>
            <View style={{ width: '50%', paddingLeft: 12, paddingRight: 12 }}>
                <View style={{ display: 'flex' }} >
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", }}>
                        <Text style={{ color: "#757575", fontWeight: 500, paddingBottom: "4px" }}>Customer Details</Text>
                    </View>
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", }}>
                        <Text style={{ fontWeight: 500 }}>AMS JOB Identifier (CID):</Text>
                        <Text style={{ textAlign: "right" }}>1234567</Text>
                    </View>
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", marginTop: 10 }}>
                        <Text style={{ color: "#757575", fontWeight: 500, paddingBottom: "4px" }}>Customer (Shipper)</Text>
                    </View>
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", marginTop: 6 }}>
                        <Text style={{ fontWeight: 500 }}>Name:</Text>
                        <Text style={{ textAlign: "right" }}>Test Test</Text>
                    </View>
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", marginTop: 6 }}>
                        <Text style={{ fontWeight: 500 }}>Origin:</Text>
                        <Text style={{ textAlign: "right" }}>456 Skillman Street {'\n'} Dallas, TX 75007</Text>
                    </View>
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", marginTop: 6 }}>
                        <Text style={{ fontWeight: 500 }}>Origin Phone:</Text>
                        <Text style={{ textAlign: "right" }}>(469) 461-5000</Text>
                    </View>
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", marginTop: 6 }}>
                        <Text style={{ fontWeight: 500 }}>Email:</Text>
                        <Link style={{ textAlign: "right" }}>ams@allmysons.com</Link>
                    </View>
                </View>
            </View>
            <View style={{ width: '50%', paddingLeft: 12, paddingRight: 12 }}>
                <View style={{ display: 'flex' }} >
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", }}>
                        <Text style={{ color: "#757575", fontWeight: 500, paddingBottom: "4px" }}>{" "}</Text>
                    </View>
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", }}>
                        <Text style={{ fontWeight: 500 }}>{" "}</Text>
                        <Text style={{ textAlign: "right" }}>{" "}</Text>
                    </View>
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", marginTop: 10 }}>
                        <Text style={{ color: "#757575", fontWeight: 500, paddingBottom: "4px" }}>Consignee:</Text>
                    </View>
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", marginTop: 6 }}>
                        <Text style={{ fontWeight: 500 }}>Name:</Text>
                        <Text style={{ textAlign: "right" }}>Test Test</Text>
                    </View>
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", marginTop: 6 }}>
                        <Text style={{ fontWeight: 500 }}>Destination Address:</Text>
                        <Text style={{ textAlign: "right" }}>456 Main Street {'\n'} Dallas, TX 75007</Text>
                    </View>
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", marginTop: 6 }}>
                        <Text style={{ fontWeight: 500 }}>Destination Phone:</Text>
                        <Text style={{ textAlign: "right" }}>(469) 461-5000</Text>
                    </View>
                    <View style={{ display: 'flex', flexDirection: 'row', justifyContent: "space-between", marginTop: 6 }}>
                        <Text style={{ fontWeight: 500 }}>{" "}</Text>
                        <Text style={{ textAlign: "right" }}>{" "}</Text>
                    </View>
                </View>
            </View>
        </View>
    )
}

export default CustomerSection